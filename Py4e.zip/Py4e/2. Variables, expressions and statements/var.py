name = input("Enter your name: ")
print("Welcome, " + name)
usd = input("Enter amount of money needed to be convert: ")
x = float(usd)
y = 22645
vnd = x * y
original = str(x)
converted = str(vnd)
print(original+ "USD = " + converted + "VND")