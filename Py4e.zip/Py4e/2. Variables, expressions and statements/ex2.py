hrs = input("Enter Hours:")
rate = input("Enter rate:")
x = float(hrs)
y = float(rate)
pay = x * y
z = str(pay)
print('Pay: ' + z)
